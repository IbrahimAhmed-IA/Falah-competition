const express = require('express');
const router = express.Router();
const competitionController = require('../controllers/competitionController');
const { authenticateToken, isAdmin, isParticipant } = require('../middleware/auth');

// Get all competitions (public)
router.get('/', competitionController.getAllCompetitions);

// Get competition by ID (public)
router.get('/:competitionId', competitionController.getCompetitionById);

// Create competition (admin only)
router.post('/', authenticateToken, isAdmin, competitionController.createCompetition);

// Update competition (admin only)
router.put('/:competitionId', authenticateToken, isAdmin, competitionController.updateCompetition);

// Complete competition (admin only)
router.put('/:competitionId/complete', authenticateToken, isAdmin, competitionController.completeCompetition);

// Join competition (participant only)
router.post('/:competitionId/join', authenticateToken, isParticipant, competitionController.joinCompetition);

// Generate matchups (admin only)
router.post('/:competitionId/matchups', authenticateToken, isAdmin, competitionController.generateMatchups);

// Update matchup score (admin only)
router.put('/matchups/:matchupId', authenticateToken, isAdmin, competitionController.updateMatchupScore);

module.exports = router;
