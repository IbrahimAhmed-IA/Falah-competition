import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ExclamationTriangleIcon } from "@radix-ui/react-icons";

interface Competition {
  id: number;
  name: string;
  status: string;
  score: number;
}

interface NameChangeRequest {
  id: number;
  new_name: string;
  requested_at: string;
}

interface ParticipantProfile {
  participant: {
    id: number;
    username: string;
    display_name: string;
  };
  competitions: Competition[];
  pendingNameChangeRequest: NameChangeRequest | null;
}

const ParticipantDashboard = () => {
  const { token, user } = useAuth();
  const [profile, setProfile] = useState<ParticipantProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch("/api/participants/profile", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          setProfile(data);
        } else {
          const errorData = await response.json();
          setError(errorData.message || "Failed to load profile");
        }
      } catch (err) {
        setError("Error fetching profile data");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    if (token) {
      fetchProfile();
    }
  }, [token]);

  if (loading) {
    return <div className="text-center p-8">Loading...</div>;
  }

  if (error) {
    return (
      <Alert variant="destructive" className="mb-6">
        <ExclamationTriangleIcon className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  const activeCompetitions = profile?.competitions.filter(c => c.status === "active") || [];
  const upcomingCompetitions = profile?.competitions.filter(c => c.status === "upcoming") || [];
  const completedCompetitions = profile?.competitions.filter(c => c.status === "completed") || [];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Participant Dashboard</h1>
        <Link to="/competitions">
          <Button>Browse Competitions</Button>
        </Link>
      </div>

      {/* Welcome Card */}
      <Card>
        <CardHeader>
          <CardTitle>Welcome, {user?.displayName}</CardTitle>
          <CardDescription>
            Your personal competition dashboard
          </CardDescription>
        </CardHeader>
        <CardContent>
          {profile?.pendingNameChangeRequest && (
            <Alert className="mb-4 bg-blue-50 dark:bg-blue-900 border-blue-200 dark:border-blue-800">
              <AlertDescription>
                You have a pending name change request to "{profile.pendingNameChangeRequest.new_name}".
              </AlertDescription>
            </Alert>
          )}

          <div className="grid gap-4">
            <div>
              <h3 className="text-lg font-medium">Your Stats</h3>
              <div className="grid grid-cols-3 gap-4 mt-2">
                <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg text-center">
                  <p className="text-sm text-gray-500 dark:text-gray-400">Active Competitions</p>
                  <p className="text-2xl font-bold">{activeCompetitions.length}</p>
                </div>
                <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg text-center">
                  <p className="text-sm text-gray-500 dark:text-gray-400">Upcoming</p>
                  <p className="text-2xl font-bold">{upcomingCompetitions.length}</p>
                </div>
                <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg text-center">
                  <p className="text-sm text-gray-500 dark:text-gray-400">Completed</p>
                  <p className="text-2xl font-bold">{completedCompetitions.length}</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Competitions */}
      {activeCompetitions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Active Competitions</CardTitle>
            <CardDescription>
              Competitions you are currently participating in
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {activeCompetitions.map((competition) => (
                <div
                  key={competition.id}
                  className="flex justify-between items-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                >
                  <div>
                    <h3 className="font-medium">{competition.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Your current score: {competition.score}
                    </p>
                  </div>
                  <Link to={`/competitions/${competition.id}`}>
                    <Button variant="outline" size="sm">View</Button>
                  </Link>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Activity Placeholder */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 dark:text-gray-400">
            {completedCompetitions.length > 0
              ? "Check your performance in previous competitions."
              : "You haven't completed any competitions yet."}
          </p>

          {completedCompetitions.length > 0 && (
            <div className="grid gap-4 mt-4">
              {completedCompetitions.slice(0, 3).map((competition) => (
                <div
                  key={competition.id}
                  className="flex justify-between items-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                >
                  <div>
                    <h3 className="font-medium">{competition.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Final score: {competition.score}
                    </p>
                  </div>
                  <Link to={`/competitions/${competition.id}`}>
                    <Button variant="outline" size="sm">Details</Button>
                  </Link>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ParticipantDashboard;
